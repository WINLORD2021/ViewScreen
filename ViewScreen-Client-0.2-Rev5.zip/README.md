# ViewScreen Client 0.2 — UI Revision 5 (MirrorBack Lab)

Native Android client based on the earlier MirrorBack laboratory project. UI Revision 5 is the approved design reference (`design/ViewScreen_UI_Test_Rev5.html`); Revision 6 is not included. The app uses native Android controls and a TextureView rather than running the HTML demo.

- Single centered 16:9 MirrorBack window; light-only palette, rounded corners, system typography, Lucide-style vector icons.
- Header screenshot and gallery actions, fullscreen control bottom-right, centered connection/status row. Gallery is a modal, with full-screen photo viewing and long-press deletion selection.
- Offline/discovery states and explicit Connect action. Existing local Wi-Fi discovery is unchanged. No live MirrorBack authorization or session negotiation is implemented; detection does not grant viewing permission. Use only with the panel owner's authorization.
- The local image test plays the existing synthetic H.264 asset, tests interruption/recovery and captures frames to private storage. The speed field reports local replay throughput in the test, not measured internet speed. Real connection speed and device name remain unavailable until a real authorized session exists.
- No remote control, microphone, audio or media upload. No new runtime permissions. The original separate host app is not included or modified.

## Build

Android 8+; compile/target SDK 35; AGP 8.8.2; Gradle 8.10.2; JDK 17. Application ID `com.viewscreen.client`; versionName `0.2-rev5`, versionCode 3. GitHub Actions workflow is supplied separately. Use the original release key to install updates in place; temporary signing keys are for fresh installs only.

`bash tests/run.sh` validates 150 synthetic packets, H.264 SPS, malformed/truncated input, discovery fixtures and stability transitions. Java syntax is checked locally. The native APK and on-device UI/codec were not executed here; Android SDK and Gradle are not installed in the local packaging environment. `ANALYSIS.md` is retained as historical baseline documentation, not a claim that real streaming is implemented.
