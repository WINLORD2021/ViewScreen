package com.viewscreen.client;
import java.io.*;
/** Wire format observed in classes2.dex, rsc$c.run; no session/authentication logic. */
public final class MirrorPacket {
 public static final int MAX_LENGTH=2097112, META_LENGTH=24;
 public final long[] times; public final byte[] data;
 private MirrorPacket(long[] t,byte[] d){times=t;data=d;}
 public static MirrorPacket read(DataInputStream in)throws IOException {
  int first=in.read(); if(first<0)return null;
  int size=(first<<24)|(in.readUnsignedByte()<<16)|(in.readUnsignedByte()<<8)|in.readUnsignedByte();
  if(size<=META_LENGTH||size>=MAX_LENGTH)throw new IOException("Недопустимый размер пакета");
  long[] times=new long[6];for(int i=0;i<times.length;i++)times[i]=Integer.toUnsignedLong(in.readInt());
  byte[] bytes=new byte[size-META_LENGTH];in.readFully(bytes);return new MirrorPacket(times,bytes);
 }
 public boolean hasNal(int type){return AvcSps.find(data,type)!=null;}
}
