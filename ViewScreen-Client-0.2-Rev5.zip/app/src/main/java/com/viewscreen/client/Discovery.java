package com.viewscreen.client;
import java.net.*;import java.nio.charset.StandardCharsets;import java.util.*;import java.io.*;
/** Device discovery only. No command to authorize, request video, or remotely control the panel. */
public final class Discovery {
 public static final int PORT=11105;
 public static byte[] request(int kind){if(kind!=3&&kind!=21)throw new IllegalArgumentException();byte[] b=new byte[128];b[0]=(byte)kind;return b;}
 public static final class Panel {public final String ip,name,extra;Panel(String i,String n,String e){ip=i;name=n;extra=e;}}
 public static Panel parse(byte[] b,int n,InetAddress sender)throws IOException{if(!(sender instanceof Inet4Address)||n<5||n>b.length||b[0]!=22)throw new IOException("Неизвестный ответ");int pos=1;String[] fields=new String[3];for(int i=0;i<3;i++){if(pos>=n)throw new IOException("Короткий ответ");int len=b[pos++]&255;if(pos+len>n)throw new IOException("Короткий ответ");if(i==0&&len!=4)throw new IOException("Некорректный адрес");fields[i]=i==0?InetAddress.getByAddress(Arrays.copyOfRange(b,pos,pos+len)).getHostAddress():new String(b,pos,len,StandardCharsets.UTF_8).replaceAll("[\\p{Cntrl}\\p{Cf}]", "").trim();pos+=len;}String name=fields[1].isEmpty()?"Интерактивная панель":fields[1];return new Panel(sender.getHostAddress(),name,fields[2]);}
}
