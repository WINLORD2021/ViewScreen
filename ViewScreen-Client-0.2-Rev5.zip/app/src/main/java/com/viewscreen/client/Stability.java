package com.viewscreen.client;
/** Monotonic millisecond clock is supplied by caller. Initial timeout and replay tuning are provisional. */
public final class Stability {
 public enum State { WAITING, LIVE, UNSTABLE }
 private long started,frame=-1,packet=-1;private boolean failed;
 public synchronized void begin(long now){started=now;frame=packet=-1;failed=false;}
 public synchronized void packet(long now){packet=now;}
 public synchronized void frame(long now){frame=now;failed=false;}
 public synchronized void disconnect(){failed=true;}
 public synchronized State state(long now){if(failed)return State.UNSTABLE;if(frame<0)return now-started>=6000?State.UNSTABLE:State.WAITING;if(now-frame>=3000||packet<0||now-packet>=3000)return State.UNSTABLE;return State.LIVE;}
}
