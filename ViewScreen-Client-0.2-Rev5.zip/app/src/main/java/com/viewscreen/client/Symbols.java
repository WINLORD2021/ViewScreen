package com.viewscreen.client;
import android.content.Context; import android.graphics.*; import android.view.View;
final class Symbols extends View {
 String type; int color; boolean alert; final Paint p=new Paint(3);
 Symbols(Context c,String t,int col){super(c);type=t;color=col;setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
 void warning(boolean b){alert=b;invalidate();}
 void line(Canvas c,float... a){Path q=new Path();q.moveTo(a[0],a[1]);for(int i=2;i<a.length;i+=2)q.lineTo(a[i],a[i+1]);c.drawPath(q,p);}
 void arc(Canvas c,float l,float t,float r,float b,float a,float s){c.drawArc(l,t,r,b,a,s,false,p);}
 protected void onDraw(Canvas c){super.onDraw(c);float s=Math.min(getWidth()-getPaddingLeft()-getPaddingRight(),getHeight()-getPaddingTop()-getPaddingBottom())/24f;if(s<=0)return;c.save();c.translate((getWidth()-24*s)/2,(getHeight()-24*s)/2);c.scale(s,s);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.8f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
 switch(type){case "wifi-off":case "wifi":Path wifi=new Path();wifi.moveTo(2,8.82f);wifi.cubicTo(7.7f,3.7f,16.3f,3.7f,22,8.82f);wifi.moveTo(5,12.859f);wifi.cubicTo(9,9.05f,15,9.05f,19,12.859f);wifi.moveTo(8.5f,16.429f);wifi.cubicTo(10.4f,14.5f,13.6f,14.5f,15.5f,16.429f);c.drawPath(wifi,p);if(type.equals("wifi-off")){p.setColor(Color.WHITE);p.setStrokeWidth(4.5f);line(c,2,2,22,22);p.setColor(color);p.setStrokeWidth(1.8f);line(c,2,2,22,22);}if(alert){p.setColor(Color.WHITE);p.setStyle(Paint.Style.FILL);c.drawRect(9,7,15,23,p);p.setStyle(Paint.Style.STROKE);p.setColor(color);line(c,12,9,12,16);}c.drawPoint(12,20,p);break;
 case "maximize":line(c,3,8,3,3,8,3);line(c,16,3,21,3,21,8);line(c,21,16,21,21,16,21);line(c,8,21,3,21,3,16);break;
 case "minimize":line(c,3,8,8,8,8,3);line(c,16,3,16,8,21,8);line(c,21,16,16,16,16,21);line(c,8,21,8,16,3,16);break;
 case "gauge":arc(c,2,2,22,22,145,250);line(c,12,14,16,10);c.drawPoint(12,14,p);break;
 case "x":line(c,6,6,18,18);line(c,18,6,6,18);break;
 case "monitor":c.drawRoundRect(2,3,22,17,2,2,p);line(c,12,17,12,21);line(c,8,21,16,21);break;
 case "devices":c.drawRoundRect(2,2,15,22,2,2,p);c.drawRoundRect(17,8,23,22,1,1,p);c.drawPoint(8.5f,19,p);c.drawPoint(20,19,p);break;
 case "sun":c.drawCircle(12,12,4,p);for(int i=0;i<8;i++){double a=i*Math.PI/4;line(c,12+(float)Math.cos(a)*8,12+(float)Math.sin(a)*8,12+(float)Math.cos(a)*10,12+(float)Math.sin(a)*10);}break;
 case "moon":Path q=new Path();q.moveTo(20,15);q.cubicTo(10,18,6,8,10,3);q.cubicTo(-1,5,1,23,14,21);q.cubicTo(17,20,19,18,20,15);c.drawPath(q,p);break;
 case "camera":line(c,3,7,7,7,9,4,15,4,17,7,21,7,21,20,3,20,3,7);c.drawCircle(12,13,4,p);break;
 case "images":c.drawRoundRect(6,3,21,18,2,2,p);line(c,3,6,3,21,18,21);c.drawCircle(11,8,1.4f,p);line(c,7,16,12,11,16,15,19,12);break;
 case "trash":line(c,3,6,21,6);line(c,9,6,9,3,15,3,15,6);line(c,5,6,6,21,18,21,19,6);line(c,10,10,10,17);line(c,14,10,14,17);break;
 case "back":line(c,12,5,5,12,12,19);line(c,5,12,21,12);break;
 default:line(c,2,8,2,3,22,3,22,21,13,21);arc(c,-8,11,12,31,270,90);arc(c,-4,15,8,27,270,90);c.drawPoint(2,21,p);
 }c.restore();}
}
