package com.viewscreen.client;
import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;
public class ProtocolTest {
 static void check(boolean ok,String s){if(!ok)throw new AssertionError(s);}
 public static void main(String[] args)throws Exception{
  try(DataInputStream in=new DataInputStream(new FileInputStream(args[0]))){int count=0;MirrorPacket p;while((p=MirrorPacket.read(in))!=null){if(p.hasNal(7)){int[] wh=AvcSps.size(AvcSps.find(p.data,7));check(wh[0]==1280&&wh[1]==720,"SPS dimensions");}check(p.times[5]==count*1000/30,"timestamp");count++;}check(count==150,"packet count");}
  for(int n:new int[]{0,23,24,2097112,-1}){ByteArrayOutputStream b=new ByteArrayOutputStream();new DataOutputStream(b).writeInt(n);try{MirrorPacket.read(new DataInputStream(new ByteArrayInputStream(b.toByteArray())));throw new AssertionError("invalid length accepted");}catch(IOException expected){}}
  try{MirrorPacket.read(new DataInputStream(new ByteArrayInputStream(new byte[]{0,0,0,25,0})));throw new AssertionError("truncated packet accepted");}catch(EOFException expected){}
  for(int type:new int[]{3,21}){byte[] r=Discovery.request(type);check(r.length==128&&r[0]==type,"request");for(int i=1;i<128;i++)check(r[i]==0,"padding");}
  ByteArrayOutputStream reply=new ByteArrayOutputStream();reply.write(22);reply.write(4);reply.write(new byte[]{(byte)192,(byte)168,4,1});byte[] name="Панель".getBytes(StandardCharsets.UTF_8);reply.write(name.length);reply.write(name);reply.write(0);byte[] packet=reply.toByteArray();Discovery.Panel panel=Discovery.parse(packet,packet.length,InetAddress.getByName("192.168.4.1"));check(panel.name.equals("Панель")&&panel.ip.equals("192.168.4.1"),"discovery reply");
  for(int n=0;n<packet.length;n++){try{Discovery.parse(packet,n,InetAddress.getByName("192.168.4.1"));throw new AssertionError("truncated discovery accepted");}catch(IOException expected){}}
  Stability s=new Stability();s.begin(100);check(s.state(100)==Stability.State.WAITING,"initial");check(s.state(6100)==Stability.State.UNSTABLE,"first frame timeout");s.packet(7000);s.frame(7001);check(s.state(7002)==Stability.State.LIVE,"live");s.packet(10000);check(s.state(10001)==Stability.State.UNSTABLE,"stalled render");s.frame(10002);check(s.state(10003)==Stability.State.LIVE,"recovered");s.disconnect();check(s.state(10004)==Stability.State.UNSTABLE,"disconnect");s.packet(10005);s.frame(10006);check(s.state(10006)==Stability.State.LIVE,"restored");
  System.out.println("PASS: 150 MirrorBack-format packets, SPS 1280x720, malformed/truncated input, discovery fixtures, stability transitions");
 }
}
