#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
javac -d "$tmp" app/src/main/java/com/viewscreen/client/{MirrorPacket,AvcSps,Discovery,Stability}.java tests/ProtocolTest.java
java -cp "$tmp" com.viewscreen.client.ProtocolTest app/src/main/assets/test_stream.bin
