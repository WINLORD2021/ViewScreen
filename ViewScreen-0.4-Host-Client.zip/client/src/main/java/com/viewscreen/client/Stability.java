package com.viewscreen.client;
/** Frame silence is not a network failure. Low goodput is meaningful only under load. */
public final class Stability {
 public enum State { WAITING, LIVE, UNSTABLE, RECONNECTING }
 private long frame=-1, packet=-1, lowSince=-1, pressure=-1;private boolean failed;
 public synchronized void begin(long now){frame=packet=lowSince=pressure=-1;failed=false;}
 public synchronized void packet(long now){packet=now;}
 public synchronized void frame(long now){frame=now;failed=false;}
 public synchronized void pressure(long now){pressure=now;}
 public synchronized void sample(long now,double mbps){if(frame<0||pressure<0||now-pressure>8000||mbps>0.3){lowSince=-1;return;}if(lowSince<0)lowSince=now;}
 public synchronized void disconnect(){failed=true;lowSince=-1;}
 public synchronized State state(long now){if(failed)return State.RECONNECTING;if(frame<0)return State.WAITING;if(lowSince>=0&&now-lowSince>=5000&&pressure>=0&&now-pressure<=8000)return State.UNSTABLE;return State.LIVE;}
}
