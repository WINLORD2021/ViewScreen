package com.viewscreen.client;
/** Fit a source aspect ratio inside available bounds without stretching or cropping. */
public final class Aspect {
 public static int[] fit(int w,int h,int sw,int sh){if(w<1||h<1||sw<1||sh<1)return new int[]{1,1};double scale=Math.min(w/(double)sw,h/(double)sh);return new int[]{Math.max(1,Math.min(w,(int)Math.round(sw*scale))),Math.max(1,Math.min(h,(int)Math.round(sh*scale)))};}
}
