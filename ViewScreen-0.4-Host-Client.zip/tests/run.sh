#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
cmp host/src/main/java/com/viewscreen/protocol/Link.java client/src/main/java/com/viewscreen/protocol/Link.java
javac -d "$work" host/src/main/java/com/viewscreen/protocol/Link.java client/src/main/java/com/viewscreen/client/{Discovery,Stability,Aspect}.java tests/ProtocolTest.java
java -cp "$work" com.viewscreen.protocol.ProtocolTest
