# ViewScreen 0.3 — Host + Client / UI Rev5

Independent LAN screen sharing. Not compatible with QuickShare/MirrorBack proprietary protocol.

## Use
1. Install ViewScreen Host on an Android 8+ interactive panel. Install ViewScreen Client on an Android 8+ tablet.
2. Connect both to the same private IPv4 LAN (panel hotspot, Wi-Fi router, or Ethernet/Wi-Fi bridge with client isolation disabled). No Internet access is required.
3. Open Host. Note its displayed IP and 22-character case-sensitive pairing code before starting. The code is hidden when screen capture starts; it is regenerated after the session ends. Share it only with authorized viewers.
4. Tap Start streaming on Host and grant Android's screen capture permission. The host's visible foreground-service notification allows stopping the session. Protected/DRM screen contents are not captured.
5. Open Client. Tap Connect when the panel is discovered, select the panel if necessary, and enter the pairing code. If broadcast discovery is blocked, use Connect by IP. Disconnect from the client with the bottom button or Back (exit fullscreen first). Stopping Host ends all sessions; a fresh host session requires its new code.

## Architecture
- UDP 8766: ViewScreen 03 discovery; unauthenticated device names are hints only.
- TCP 8765: VS03 read-only video. Fresh random challenge nonces, mutual HMAC-SHA256 authentication, per-connection AES-128-GCM keys, monotonic record sequence. 128-bit randomly generated session secret, no low-entropy PIN. Secret never transmitted. No audio, file transfer, microphone, remote control, cloud or Internet forwarding.
- MediaProjection + AVC encoder on Host, MediaCodec + TextureView on Client. Host negotiates encoder capability locally (up to 1080p, 30 fps); client fits decoded image within the Rev5 window. Source orientation is selected at capture start; restart capture after panel rotation if necessary. Client's speed is incoming video payload throughput, not an Internet speed test.
- Screenshots saved privately on client; gallery/fullscreen and long-press deletion preserved. Adaptive reduced-size launcher icon.
- Network errors retry automatically, authentication rejection requires a new pairing attempt. Discovery is limited to the private local subnet. Host session code is required for every client. This is a new application protocol; its use of standard cryptographic primitives has not undergone an independent security audit and it does not provide forward secrecy.

## Build and verification
Unzip to project root; JDK 17 / Gradle 8.10.2 / Android SDK 35 + build-tools 35.0.0. Run `bash tests/run.sh`, then `gradle :host:assembleRelease :client:assembleRelease` with signing environment variables set by CI. APK application IDs remain com.viewscreen.host and com.viewscreen.client. Version code 4; minSdk 26; targetSdk 35.

Local JVM tests: TCP loopback handshake, wrong pairing secret, 200 encrypted records across fresh connections, header/heartbeat, tamper/replay rejection, discovery parser, stability logic. No Android SDK or physical panel/tablet available in authoring environment. Actual Android compilation, screen capture, codec compatibility, network discovery on target hardware, and end-to-end playback remain unverified. No test video is bundled or played by the apps.
