package com.viewscreen.client;
import com.viewscreen.protocol.Link;
import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;
public final class Discovery {
 public static final int PORT=Link.UDP;
 public static byte[] request(){return Link.FIND.getBytes(StandardCharsets.UTF_8);}
 public static final class Panel {public final String ip,name;Panel(String i,String n){ip=i;name=n;}}
 public static Panel parse(byte[] b,int n,InetAddress sender)throws IOException{if(!(sender instanceof Inet4Address)||!sender.isSiteLocalAddress()||n<1||n>512)throw new IOException();String msg=new String(b,0,n,StandardCharsets.UTF_8);if(!msg.startsWith(Link.REPLY))throw new IOException();String name=msg.substring(Link.REPLY.length()).replaceAll("[\\p{Cntrl}\\p{Cf}]","").trim();return new Panel(sender.getHostAddress(),name.isEmpty()?"ViewScreen Host":name.substring(0,Math.min(80,name.length())));}
}
