package com.viewscreen.protocol;
import java.io.*;
import java.net.*;
import java.security.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;

/** VS03: authenticated, encrypted, read-only screen transport. Session keys are never sent. */
public final class Link {
 public static final int MAGIC=0x56533033, TCP=8765, UDP=8766, MAX=8*1024*1024+32;
 public static final String FIND="VIEWSCREEN-03?", REPLY="VIEWSCREEN-03:";
 private static final SecureRandom RNG=new SecureRandom();
 public static byte[] random(int n){byte[] a=new byte[n];RNG.nextBytes(a);return a;}
 public static String newCode(){return Base64.getUrlEncoder().withoutPadding().encodeToString(random(16));}
 public static byte[] code(String s){byte[] a=Base64.getUrlDecoder().decode(s.trim());if(a.length!=16)throw new IllegalArgumentException("Invalid pairing code");return a;}
 private static byte[] mac(byte[] key,String label,byte[] a,byte[] b)throws GeneralSecurityException{Mac m=Mac.getInstance("HmacSHA256");m.init(new SecretKeySpec(key,"HmacSHA256"));m.update(label.getBytes(StandardCharsets.US_ASCII));m.update(a);m.update(b);return m.doFinal();}
 private static byte[] read(DataInputStream in,int n)throws IOException{byte[] b=new byte[n];in.readFully(b);return b;}
 public static final class AuthException extends IOException {public AuthException(){super("Pairing rejected");}}
 public static Channel host(Socket s,byte[] key)throws IOException,GeneralSecurityException{
  DataInputStream in=new DataInputStream(new BufferedInputStream(s.getInputStream()));DataOutputStream out=new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
  if(in.readInt()!=MAGIC)throw new AuthException();byte[] c=read(in,32),h=random(32);out.writeInt(MAGIC);out.write(h);out.write(mac(key,"VS03 host",c,h));out.flush();
  if(!MessageDigest.isEqual(read(in,32),mac(key,"VS03 client",c,h)))throw new AuthException();
  return new Channel(in,out,mac(key,"VS03 video",c,h));
 }
 public static Channel client(Socket s,byte[] key)throws IOException,GeneralSecurityException{
  DataInputStream in=new DataInputStream(new BufferedInputStream(s.getInputStream()));DataOutputStream out=new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
  byte[] c=random(32);out.writeInt(MAGIC);out.write(c);out.flush();if(in.readInt()!=MAGIC)throw new AuthException();byte[] h=read(in,32);if(!MessageDigest.isEqual(read(in,32),mac(key,"VS03 host",c,h)))throw new AuthException();out.write(mac(key,"VS03 client",c,h));out.flush();return new Channel(in,out,mac(key,"VS03 video",c,h));
 }
 public static final class Channel {
  private final DataInputStream in;private final DataOutputStream out;private final SecretKeySpec key;private long seq=0;
  Channel(DataInputStream i,DataOutputStream o,byte[] k){in=i;out=o;key=new SecretKeySpec(Arrays.copyOf(k,16),"AES");}
  private Cipher cipher(int mode,int len)throws GeneralSecurityException{if(seq==Long.MAX_VALUE)throw new GeneralSecurityException("Sequence exhausted");byte[] nonce=ByteBuffer.allocate(12).putInt(MAGIC).putLong(seq++).array();Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(mode,key,new GCMParameterSpec(128,nonce));c.updateAAD(ByteBuffer.allocate(4).putInt(len).array());return c;}
  public void send(byte[] record)throws IOException,GeneralSecurityException{if(record.length>MAX)throw new IOException("Record too large");int n=record.length+16;byte[] encrypted=cipher(Cipher.ENCRYPT_MODE,n).doFinal(record);out.writeInt(n);out.write(encrypted);out.flush();}
  public byte[] receive()throws IOException,GeneralSecurityException{int n=in.readInt();if(n<16||n>MAX+16)throw new IOException("Invalid record length");return cipher(Cipher.DECRYPT_MODE,n).doFinal(read(in,n));}
 }
 public static byte[] header(int w,int h,int fps,byte[] a,byte[] b,String name)throws IOException{ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream d=new DataOutputStream(bytes);d.writeByte(1);d.writeInt(w);d.writeInt(h);d.writeInt(fps);d.writeInt(a.length);d.write(a);d.writeInt(b.length);d.write(b);d.writeUTF(name.length()>80?name.substring(0,80):name);return bytes.toByteArray();}
 public static byte[] frame(byte[] data,long pts,int flags){return ByteBuffer.allocate(13+data.length).put((byte)2).putLong(pts).putInt(flags).put(data).array();}
 public static byte[] heartbeat(){return new byte[]{3};}
 public static byte[] sized(DataInputStream in,int max)throws IOException{int n=in.readInt();if(n<0||n>max)throw new IOException("Invalid length");return read(in,n);}
}
