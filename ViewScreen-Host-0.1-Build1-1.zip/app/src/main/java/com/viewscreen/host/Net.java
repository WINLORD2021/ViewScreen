package com.viewscreen.host;
import java.net.*;import java.util.*;
final class Net {
 static final int TCP=8765,UDP=8766,MAGIC=0x56533031, MAX=8*1024*1024;
 static final String FIND="VIEWSCREEN-01?",REPLY="VIEWSCREEN-01:";
 static boolean local(InetAddress addr){if(!(addr instanceof Inet4Address)||!addr.isSiteLocalAddress())return false;try{for(NetworkInterface n:Collections.list(NetworkInterface.getNetworkInterfaces()))if(n.isUp()&&!n.isLoopback())for(InterfaceAddress a:n.getInterfaceAddresses()){if(!(a.getAddress() instanceof Inet4Address))continue;int bits=a.getNetworkPrefixLength();if(bits<=0||bits>32)continue;int mask=-1 << (32-bits);if((num(addr)&mask)==(num(a.getAddress())&mask))return true;}}catch(Exception e){}return false;}
 static int num(InetAddress a){int n=0;for(byte b:a.getAddress())n=(n<<8)|(b&255);return n;}
 static List<InetAddress> broadcasts(){List<InetAddress> list=new ArrayList<>();try{for(NetworkInterface n:Collections.list(NetworkInterface.getNetworkInterfaces()))if(n.isUp()&&!n.isLoopback())for(InterfaceAddress a:n.getInterfaceAddresses())if(a.getBroadcast()!=null && a.getAddress().isSiteLocalAddress())list.add(a.getBroadcast());}catch(Exception e){}return list;}
 static boolean hasLocal(){return !broadcasts().isEmpty();}
}
